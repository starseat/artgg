const STUDIO_GLOBAL = {
  ID: 'studio-front',
  API: 'https://s-studio.co.kr/studios-api/',
  LANG: location.pathname.indexOf('/en/') >= 0 ? '2' : '1'
};